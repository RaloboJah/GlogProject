package fr.emse.test;

public interface IMoney {
	
	IMoney add(IMoney money);

}
